Written by Don Kackman dkackman@users.sourceforge.net

License: None, use as you see fit.

The <contact/> tag is meant as a simple demonstration of implementing a custom NDoc tag.
		
It also serves as a template for those wishing to submit their own
custom tags to ndoc-contrib@lists.sourceforge.net.
		
The tag itself is meant for in-house documentation so that readers would 
know who to contact if they have a question about a type of member.