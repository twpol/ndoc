using System;

namespace NDoc.Contrib.ContactTag
{
	/// <summary>
	/// This class demonstrates a simple custom tag
	/// </summary>
	/// <contact href="mailto:noone@example.org">don</contact>
	public class Example
	{	
		/// <summary>
		/// This method uses the contact tag wthout text, just an href
		/// </summary>
		/// <contact href="mailto:noone@example.org"/>
		public void NoText()
		{

		}
	}
}
	